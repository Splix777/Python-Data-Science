# my_module.py

def count_in_list(list: list, item: int) -> int:
    """
    A function that counts the number of times an item appears in a list
    """
    return list.count(item)
